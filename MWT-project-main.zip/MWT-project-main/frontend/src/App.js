import React from "react";
import Homepage from "./screens/Homepage";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SignUpOut from "./screens/Signup";
import Payment from "./screens/Payment";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Homepage />} />

          <Route path="/Sign-up" element={<SignUpOut/>}/>

          <Route path="/cart" element={<Payment />} />
          
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
