import React, { useState, useEffect } from "react";
import "../css/product.css";

function Product() {
  const [album, setAlbum] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://ws.audioscrobbler.com/2.0/?method=tag.gettopalbums&tag=disco&api_key=6f2571d169c3b6230c53ba7452cf0b77&format=json"
        );
        const data = await response.json();
        if (data?.albums?.album?.length) {
          setAlbum(data.albums.album[0]);
        }
      } catch (error) {
        console.error("Error fetching the album data: ", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="product">
      {album ? (
        <div className="product_container">
          <div className="product_info">
            <p>{album.name}</p>
            <p>{album.artist.name}</p>
            <p className="product_price">
              <small>$</small>
              <strong>9.99</strong>
            </p>
            <div className="product_rating">⭐⭐⭐⭐⭐</div>
            </div>
            <img
              className="product_img"
              src={album?.image?.[2]?.["#text"] || "default-placeholder.png"}
              alt={album.name}
              style={{
                maxHeight: 200,
                width: "100%",
                resizeMode: "contain",
                marginBottom: 15,
                borderRadius: 8,
              }}
            />
            <button>Add to cart</button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default Product
