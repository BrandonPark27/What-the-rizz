import React from "react";
import "../css/header.css";
import { Link } from "react-router-dom";
import ShoppingBasketIcon from "@mui/icons-material/ShoppingBasket";
import SearchIcon from "@mui/icons-material/Search";

function Header() {
  return (
    <div className="header">
      <h1>Albumzone</h1>
      <div className="header_search">
        <input className="header_search_input" type="text" />
        <SearchIcon className="header_search_Icon" />
      </div>
      <div className="header_nav">
        <div className="header_option">
          <span className="header_option_line1">Hello Guest</span>
          <Link to="sign-up" className="header_option_line2">
            Sign In
          </Link>
        </div>
        <div className="header_option">
          <span className="header_option_line1">Returns</span>
          <span className="header_option_line2">& Orders</span>
        </div>
        <div className="header_option"></div>
        <div className="header_option_cart">
        <Link to="/cart" className="header_option_cart">
        <ShoppingBasketIcon />
        <span className="header_option_line2 header_cart_count">0</span>
        </Link>
      </div>
      </div>
    </div>
  );
}

export default Header;
