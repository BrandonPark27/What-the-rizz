import React from "react";
import Header from "./Header";
import "../css/homepage.css";
import Product from "../components/Product";

function Homepage() {
  return (
    <>
      <Header/>
      <Home />
    </>
  );
}

function Home() {
  return (
    <div className="home">
      <div className="home_container">
        <img className="home_banner"
          src={require('.//banner.png')}
          alt=""
        />
        <div className="home_row">
        <Product/>
        <Product/>
        <Product/>
        <Product/>

      </div>
      <div className="home_row">
      <Product/>

      </div>
      <div className="home_row">

      </div>
      </div>
    </div>
  );
}

export default Homepage;
